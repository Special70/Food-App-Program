# Debug Mode. If enabled, all dbugprint() calls will print text
debug_mode = True
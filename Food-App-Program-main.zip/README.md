# Food Order Program
- You can use arrow keys, enter/exit keys and various inputs to use the program.

# Developer Notes:
- Refer to documentation.txt to learn more about the source code.
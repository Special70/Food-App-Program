_001_front_menu = [
    f"Hit UP and DOWN Keys to move. Hit ENTER to select.",
    f"",
    f"============================",
    f"Welcome to TastyPal!",
    f"============================",
    f"%0% Open",
    f"%1% Exit",
    f""
    ]

_002_main_menu = [
    f"Hit UP, DOWN, LEFT, RIGHT Keys to move. Hit ENTER to select.",
    f"%searchbar_guide%",
    f"==============================================================",
    f"================== %side0% Search : %text%_",
    f"====|============|============================================",
    f"====| %side1% Back       | ",
    f"====| Sort:        | %selector0% %line0%",
    f"====| %side2% Name       | %selector1% %line1%",
    f"====| %side3% Shops      | %selector2% %line2%",
    f"====| %side4% Products   | %selector3% %line3%",
    f"====|              | %selector4% %line4%",
    f"====| %side6%            | %selector5% %line5%",
    f"====|              | %selector6% %line6%",
    f"====|              | ",
    f""
]
